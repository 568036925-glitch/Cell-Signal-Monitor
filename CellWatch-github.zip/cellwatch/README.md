# CellWatch

面向现代 Android（API 23–34）的**无 root** 小区侦测 / 启发式伪基站提醒小工具。
为一个在 Android 10+ 上已无法工作的老项目（AIMSICD 0.1.43）重写的替代品。

> 这是一个**全新编写**的项目（clean-room），不含 AIMSICD 的代码，因此可以直接用 MIT 发布。
> 如果你要复用 AIMSICD 的代码/资源，那部分必须遵守其 GPLv3 许可。

> 完整说明（非原创来源声明、规则详解、法律边界、构建步骤）见 **[MANUAL.md](MANUAL.md)**。

## 给新手：直接安装（不用编译）

包里已经放好现成的 APK：

```
prebuilt/CellWatch-1.5.apk
```

1. 下载 → 传到手机 → 点开安装（允许“安装未知来源应用”）；
2. 首次打开：位置权限选 **精确位置**，并允许 **电话**；
3. 界面每 3 秒刷新一次，能看到“服务小区 / 邻区 / 周边 WiFi”即正常。

> 该 APK 使用 Android 调试证书签名，部分机型（ColorOS / MIUI）会提示“未通过安全检测”，
> 点“仍要安装”即可。正式分发建议用自己的 keystore 重签（见下方「自行构建」）。

## 给进阶用户：自己组合

仓库本身就是完整 Gradle 工程，可以任意裁剪：

| 想要什么 | 改哪里 |
|---|---|
| 去掉 WiFi 扫描 | 删 `Wifi.java` + `MainActivity` 里的 WiFi 区块 |
| 改检测判据 | 只改 `Rules.java`（12 条规则集中在这一个文件） |
| 换/加语言 | 只改 `L.java`（双语字典，加一对 `d("key", "中文", "English")` 即可） |
| 离线数据分析 | `analyze.mjs` 可单独拷走，不依赖 APK |
| 只保留 CSV | `Store.java` 的 `exportJson` 可删 |

## 先澄清一件事：能不能"侦测周围的电话号码"？

**不能，而且没有任何"只收不发"的做法。**

- 手机号（MSISDN）**不在空口广播**。手机不会向周围播报自己的号码；
  号码只存在于运营商的 HLR/HSS 里，与 IMSI 的对应关系只有运营商（或合法监听）能查。
- 空中能收到的是手机与**基站**之间的信令（TMSI/IMSI 等），而且要收它必须让射频进入
  监听/被动模式——Android 应用层没有这种能力，需要特定硬件，属于监听通信，多数司法辖区违法。
- 市面上号称"扫描周围号码"的设备，本质都是 **IMSI Catcher / 短信嗅探器**，
  靠"发"（伪装基站）把手机骗过来。这正是本项目**不提供**的能力。

所以本应用只做合法且可行的部分：**基站侧侦测** + **本机自己的 SIM/号码信息**。

## 它做什么（v1.5）

每 3 秒读一次 `TelephonyManager.getAllCellInfo()`：

**服务小区**：制式 / MCC-MNC(PLMN) / LAC(TAC) / CID / PCI(PSC) / 信号 dBm /
LTE 的 RSRP、RSRQ、SINR、EARFCN、TA

**邻区排行**：按信号强度排序，显示前 8 个

**信号趋势**：最近 28 次采样的 dBm 迷你曲线（▁▂▃▄▅▆▇█）

**本机 / SIM**：运营商、SIM 运营商(MCC-MNC)、数据网络制式、漫游状态、SIM 状态、
本机号码（系统提供时）、双卡订阅列表

**12 条启发式规则**（分 高/中/低/信息 四级）
1. 同一 CID 的 LAC/TAC 变化 — 伪基站改写位置区
2. 制式回落：4G/5G → 2G/3G
3. 制式回升
4. PLMN（运营商）变化
5. 邻区数量骤降
6. 信号骤增（≥25 dBm 且 > -75）
7. 信号突变（≥20 dBm）
8. 孤岛强信号（只剩 1 个小区且信号很强）
9. 工作在 2G（信令加密强度低）
10. PCI/PSC 冲突（不同小区用了同一个 PCI）
11. 60 秒内频繁切换（乒乓切换）
12. 首次出现的新位置区（信号较强）

**其它**：SQLite 历史、CSV 导出（含 RSRP/RSRQ/SINR/EARFCN/TA）、
"分享诊断"一键导出状态+事件+崩溃信息、崩溃自动记录。

## 它做不到（平台限制，不是代码问题）

| 能力 | 原因 |
|---|---|
| 读别人手机号 | 号码不在空口广播；只有伪装基站（IMSI Catcher）才可能拿到，违法 |
| 读 IMEI / IMSI / SIM 序列号 | Android 10 起普通应用被彻底禁止 |
| 读基带 / AT 命令 / `/dev/diag` | 需要 root + 特定基带固件 |
| 判定"确凿的 IMSI Catcher" | 需要基带层数据；本应用只能做启发式提醒 |
| 上传/查询 OpenCellID | 官方旧接口已于 2017 年关停 |

## 编译

Android Studio（AGP 8.x，JDK 17）打开根目录：

```bash
./gradlew assembleRelease
```

或命令行签名：

```bash
keytool -genkeypair -v -keystore cellwatch.jks -alias cellwatch \
        -keyalg RSA -keysize 2048 -validity 10000
apksigner sign --ks cellwatch.jks --out CellWatch.apk app-release-unsigned.apk
```

**务必保管好 keystore**：以后更新必须用同一个签名，否则会安装冲突。

## 目录

```
app/src/main/java/com/chatbox/cellwatch/
├── MainActivity.java   界面 / 采样循环 / 曲线 / 按钮
├── Cells.java          反射读取 getAllCellInfo()，兼容 GSM/UMTS/LTE/NR
├── Rules.java          12 条启发式规则，带等级
├── Net.java            本机与 SIM 信息（仅本机）
├── Store.java          SQLite 历史 + CSV 导出
└── CrashLog.java       崩溃记录 + 诊断文本
```

零第三方依赖、零资源文件（界面全部代码构建），APK 二十几 KB。

## 发布到 GitHub

本仓库已包含：源码、Gradle 配置、`MANUAL.md`（双语说明书）、`CHANGELOG.md`、
`analyze.mjs`（数据分析脚本）、以及 `.github/workflows/build.yml`（CI 自动构建 APK）。

```bash
# 1) 在 GitHub 新建仓库后
git init
git add .
git commit -m "CellWatch 1.5: cell monitor for modern Android"
git branch -M main
git remote add origin https://github.com/<you>/cellwatch.git
git push -u origin main

# 2) 本地构建（需 JDK 17 + Android SDK）
gradle wrapper --gradle-version 8.7   # 仓库未附带 wrapper jar
./gradlew assembleRelease

# 3) 用自己的密钥签名（切勿提交 keystore，.gitignore 已排除）
keytool -genkeypair -v -keystore cellwatch.jks -alias cellwatch \
        -keyalg RSA -keysize 2048 -validity 10000
apksigner sign --ks cellwatch.jks --out CellWatch-1.5.apk app-release-unsigned.apk

# 4) 发布 Release，把 APK 作为 asset 上传
git tag v1.5 && git push --tags
```

**发布前请确认：**
- README / MANUAL 中的「非原创来源声明」（AIMSICD 0.1.43, GPLv3）保留；
- 不要把它描述为“可检测伪基站”，应写“检测可观测异常并评估误报率”；
- 不要把个人 keystore、个人采集数据（`*.json` / `*.csv`）提交进仓库。

## 许可

MIT（见 LICENSE）。名称与图标请自行替换，不要让人误以为是某个官方应用的官方版本。
