package com.chatbox.cellwatch;

import android.content.Context;
import android.telephony.TelephonyManager;

/** Own-device / SIM information. Everything here is about THIS phone, never other people's. */
public final class Net {

    private Net() {
    }

    public static String simStateName(int s) {
        switch (s) {
            case 1: return L.t("sim.absent");
            case 2: return L.t("sim.pin");
            case 3: return L.t("sim.puk");
            case 4: return L.t("sim.netlock");
            case 5: return L.t("sim.ready");
            case 6: return L.t("sim.notready");
            default: return L.t("sim.unknown");
        }
    }

    public static String summary(Context ctx) {
        StringBuilder sb = new StringBuilder();
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return L.t("net.no_tm");
            sb.append(L.f("net.operator", or(tm, "getNetworkOperatorName", "?"))).append('\n');

            String simOp = or(tm, "getSimOperator", "");
            String simName = or(tm, "getSimOperatorName", "?");
            sb.append(L.f("net.sim_operator", simOp.length() > 0 ? simName + " (" + simOp + ")" : simName)).append('\n');

            sb.append(L.f("net.network", netTypeName(intOf(tm, "getDataNetworkType"))));
            boolean roaming = Boolean.TRUE.equals(Cells.invoke(tm.getClass(), tm, "isNetworkRoaming"));
            sb.append("   ").append(L.f("net.roaming", L.t(roaming ? "net.yes" : "net.no"))).append('\n');

            sb.append(L.f("net.sim_state", simStateName(intOf(tm, "getSimState"))));
            String num = or(tm, "getLine1Number", "");
            sb.append("   ").append(L.f("net.own_number",
                    num.length() == 0 || "null".equals(num) ? L.t("net.not_provided") : num)).append('\n');

            sb.append(subs(ctx));
        } catch (Throwable t) {
            sb.append('\n').append(L.f("net.read_failed", t));
        }
        return sb.toString();
    }

    /** Dual-SIM subscription list, if the platform exposes it. */
    private static String subs(Context ctx) {
        StringBuilder sb = new StringBuilder();
        try {
            Object sm = ctx.getSystemService("telephony_subscription_service");
            if (sm == null) return "";
            Object list = Cells.invoke(sm.getClass(), sm, "getActiveSubscriptionInfoList");
            if (!(list instanceof java.util.List)) return "";
            java.util.List l = (java.util.List) list;
            sb.append(L.f("net.subs_count", Integer.valueOf(l.size()))).append('\n');
            for (int i = 0; i < l.size(); i++) {
                Object info = l.get(i);
                if (info == null) continue;
                Object slot = Cells.invoke(info.getClass(), info, "getSimSlotIndex");
                Object carrier = Cells.invoke(info.getClass(), info, "getCarrierName");
                Object mccs = Cells.invoke(info.getClass(), info, "getMccString");
                Object mncs = Cells.invoke(info.getClass(), info, "getMncString");
                Object num = Cells.invoke(info.getClass(), info, "getNumber");
                String number = num instanceof String && ((String) num).length() > 0
                        ? (String) num : L.t("net.not_provided");
                sb.append("  · ").append(L.t("net.card"))
                  .append(slot == null ? "?" : String.valueOf(slot))
                  .append(' ').append(carrier == null ? "?" : carrier)
                  .append(" [").append(mccs == null ? "?" : mccs).append('-').append(mncs == null ? "?" : mncs).append(']')
                  .append("  ").append(L.t("net.number")).append(' ').append(number)
                  .append('\n');
            }
        } catch (Throwable t) {
            CrashLog.note("Net.subs " + t);
        }
        return sb.toString();
    }

    private static String or(TelephonyManager tm, String name, String def) {
        Object v = Cells.invoke(tm.getClass(), tm, name);
        if (v instanceof String) {
            String s = (String) v;
            return s.length() == 0 ? def : s;
        }
        return def;
    }

    private static int intOf(TelephonyManager tm, String name) {
        Object v = Cells.invoke(tm.getClass(), tm, name);
        return v instanceof Integer ? ((Integer) v).intValue() : -1;
    }

    public static String netTypeName(int t) {
        switch (t) {
            case 1: case 2: case 4: case 7: case 11: case 16: return L.t("nettype.2g");
            case 3: case 5: case 6: case 8: case 9: case 10: case 15: case 17: return L.t("nettype.3g");
            case 13: return L.t("nettype.lte");
            case 14: return L.t("nettype.ehrpd");
            case 20: return L.t("nettype.nr");
            case 0: return L.t("nettype.none");
            default: return L.f("nettype.other", Integer.valueOf(t));
        }
    }
}
