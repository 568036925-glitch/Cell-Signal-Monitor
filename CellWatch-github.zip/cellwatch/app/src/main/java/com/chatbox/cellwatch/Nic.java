package com.chatbox.cellwatch;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;

/**
 * This device's own network interfaces and identifiers - and nothing else.
 * Cellular links are point to point, so no other subscriber's IPv6 or identity
 * is ever visible here; the OS does not expose neighbour identifiers either.
 */
public final class Nic {

    private Nic() {
    }

    private static String typeOf(String name) {
        if (name.startsWith("wlan") || name.startsWith("ap")) return L.t("net.type.wifi");
        if (name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("pdp") || name.startsWith("v4")) {
            return L.t("net.type.cell");
        }
        return L.t("net.type.other");
    }

    public static String summary(Context ctx) {
        StringBuilder sb = new StringBuilder();
        try {
            SharedPreferences p = ctx.getSharedPreferences("cellwatch", Context.MODE_PRIVATE);
            List<NetworkInterface> nifs = new ArrayList<NetworkInterface>();
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface n = en.nextElement();
                if (n == null || !n.isUp() || n.isLoopback()) continue;
                nifs.add(n);
            }
            Collections.sort(nifs, new Comparator<NetworkInterface>() {
                public int compare(NetworkInterface a, NetworkInterface b) {
                    return a.getName().compareTo(b.getName());
                }
            });

            boolean any = false;
            for (int i = 0; i < nifs.size(); i++) {
                NetworkInterface n = nifs.get(i);
                List<InetAddress> addrs = Collections.list(n.getInetAddresses());
                StringBuilder line = new StringBuilder();
                String v6prefix = null;
                for (int k = 0; k < addrs.size(); k++) {
                    InetAddress a = addrs.get(k);
                    if (a == null || a.isLoopbackAddress()) continue;
                    if (a instanceof Inet4Address) {
                        line.append("\n  IPv4 ").append(a.getHostAddress());
                    } else if (a instanceof Inet6Address) {
                        String host = a.getHostAddress();
                        int pct = host.indexOf('%');
                        if (pct > 0) host = host.substring(0, pct);
                        line.append("\n  IPv6 ").append(host);
                        if (!a.isLinkLocalAddress() && v6prefix == null) {
                            String[] parts = host.split(":");
                            if (parts.length >= 4) {
                                v6prefix = parts[0] + ":" + parts[1] + ":" + parts[2] + ":" + parts[3] + "::/64";
                            }
                        }
                    }
                }
                if (line.length() == 0) continue;
                any = true;
                sb.append(n.getName()).append(" (").append(typeOf(n.getName())).append(')').append(line).append('\n');
                if (v6prefix != null) {
                    String key = "v6prefix_" + n.getName();
                    String old = p.getString(key, null);
                    if (old == null) {
                        p.edit().putString(key, v6prefix).commit();
                        sb.append(' ').append(L.f("net.prefix.new", v6prefix)).append('\n');
                    } else if (!old.equals(v6prefix)) {
                        p.edit().putString(key, v6prefix).commit();
                        sb.append(' ').append(L.f("net.prefix.changed", v6prefix, old)).append('\n');
                    } else {
                        sb.append(' ').append(L.f("net.prefix.same", v6prefix)).append('\n');
                    }
                }
            }
            if (!any) sb.append(L.t("net.none")).append('\n');

            sb.append('\n').append(L.t("net.ids")).append('\n');
            sb.append("  Android ID: ").append(androidId(ctx)).append('\n');
            sb.append("  Build: ").append(cut(android.os.Build.FINGERPRINT)).append('\n');
            sb.append("  IMEI / IMSI: ").append(L.t("net.hidden_ids")).append('\n');
        } catch (Throwable t) {
            sb.append(L.f("net.read_failed", t));
        }
        return sb.toString();
    }

    private static String androidId(Context ctx) {
        try {
            String id = Settings.Secure.getString(ctx.getContentResolver(), "android_id");
            return id == null || id.length() == 0 ? L.t("net.not_provided") : id;
        } catch (Throwable t) {
            return L.t("net.not_provided");
        }
    }

    private static String cut(String s) {
        if (s == null) return "?";
        return s.length() > 60 ? s.substring(0, 60) + "…" : s;
    }
}
