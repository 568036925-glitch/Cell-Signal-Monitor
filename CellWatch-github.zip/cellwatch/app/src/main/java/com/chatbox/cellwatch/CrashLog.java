package com.chatbox.cellwatch;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Crash recorder + diagnostic text. Everything is defensive. */
public final class CrashLog {

    private static final String FILE = "last-crash.txt";
    private static String last = "";

    private CrashLog() {
    }

    public static String lastCrash() {
        return last;
    }

    public static void install(final Context ctx) {
        try {
            final Context app = ctx.getApplicationContext();
            last = read(app);
            Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
                public void uncaughtException(Thread t, Throwable e) {
                    String text;
                    try {
                        StringWriter sw = new StringWriter();
                        PrintWriter pw = new PrintWriter(sw);
                        pw.println(L.t("crash.title"));
                        pw.println(header(app));
                        pw.println(L.f("crash.thread", t == null ? "?" : t.getName()));
                        e.printStackTrace(pw);
                        pw.flush();
                        text = sw.toString();
                    } catch (Throwable inner) {
                        text = String.valueOf(e);
                    }
                    last = text;
                    try {
                        FileOutputStream out = new FileOutputStream(new File(app.getFilesDir(), FILE));
                        out.write(text.getBytes("UTF-8"));
                        out.flush();
                        out.close();
                    } catch (Throwable ignored) {
                    }
                    try {
                        android.os.Process.killProcess(android.os.Process.myPid());
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    public static void note(String s) {
        last = (last == null ? "" : last) + "\n[note] " + s;
    }

    public static String header(Context c) {
        StringBuilder sb = new StringBuilder();
        try {
            sb.append(L.f("crash.device", android.os.Build.MANUFACTURER, android.os.Build.MODEL)).append('\n');
            sb.append(L.f("crash.os", android.os.Build.VERSION.RELEASE,
                    String.valueOf(android.os.Build.VERSION.SDK_INT))).append('\n');
        } catch (Throwable ignored) {
        }
        return sb.toString();
    }

    private static String read(Context c) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return "";
            FileInputStream in = new FileInputStream(f);
            byte[] buf = new byte[(int) f.length()];
            int off = 0;
            int n;
            while (off < buf.length && (n = in.read(buf, off, buf.length - off)) > 0) off += n;
            in.close();
            return new String(buf, 0, off, "UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }
}
