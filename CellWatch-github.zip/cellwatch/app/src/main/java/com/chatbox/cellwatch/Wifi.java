package com.chatbox.cellwatch;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Nearby Wi-Fi access points: SSID, BSSID, signal, band, security.
 * Access-point metadata only - this says nothing about any person or phone number.
 */
public final class Wifi {

    public static final class Ap {
        public String ssid = "";
        public String bssid = "";
        public int level = -127;
        public int freq = 0;
        public boolean open = true;
        public boolean wpa3 = false;
    }

    private Wifi() {
    }

    public static List<Ap> scan(Context ctx, boolean trigger) {
        List<Ap> out = new ArrayList<Ap>();
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return out;
            if (trigger) {
                try {
                    wm.startScan();
                } catch (Throwable ignored) {
                }
            }
            List<ScanResult> res = wm.getScanResults();
            if (res == null) return out;
            for (int i = 0; i < res.size(); i++) {
                ScanResult r = res.get(i);
                if (r == null) continue;
                Ap ap = new Ap();
                ap.ssid = r.SSID == null || r.SSID.length() == 0 ? "<hidden>" : r.SSID;
                ap.bssid = r.BSSID == null ? "?" : r.BSSID;
                ap.level = r.level;
                ap.freq = r.frequency;
                String caps = r.capabilities == null ? "" : r.capabilities;
                ap.wpa3 = caps.indexOf("SAE") >= 0 || caps.indexOf("WPA3") >= 0;
                ap.open = !(caps.indexOf("WPA") >= 0 || caps.indexOf("WEP") >= 0 || ap.wpa3);
                out.add(ap);
            }
            Collections.sort(out, new Comparator<Ap>() {
                public int compare(Ap a, Ap b) {
                    return b.level - a.level;
                }
            });
        } catch (Throwable t) {
            CrashLog.note("Wifi.scan " + t);
        }
        return out;
    }

    public static String bandOf(int freq) {
        if (freq >= 5925 && freq <= 7125) return "6G";
        if (freq >= 4900 && freq < 5925) return "5G";
        if (freq >= 2400 && freq < 2500) return "2.4G";
        if (freq > 0 && freq < 2400) return "900M";
        return "?";
    }

    public static String securityOf(Ap ap) {
        if (ap.wpa3) return L.t("wifi.wpa3");
        return L.t(ap.open ? "wifi.open" : "wifi.secured");
    }
}
