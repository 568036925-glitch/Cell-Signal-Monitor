package com.chatbox.cellwatch;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;

/**
 * Tiny bilingual string table. Deliberately resource-free: the whole app ships no
 * res/ folder, so translations live here and the language can be switched at runtime.
 */
public final class L {

    private static final Map<String, String> ZH = new HashMap<String, String>();
    private static final Map<String, String> EN = new HashMap<String, String>();
    private static boolean english = false;

    private static void d(String key, String zh, String en) {
        ZH.put(key, zh);
        EN.put(key, en);
    }

    static {
        d("title.app", "CellWatch 小区侦测", "CellWatch Cell Monitor");
        d("app.header", "CellWatch 1.5 · 小区侦测（无 root）", "CellWatch 1.5 · Cell Monitor (no root)");

        d("perm.requesting", "正在申请权限…请选择【精确位置】并允许【电话】",
                "Requesting permissions… choose Precise location and allow Phone");
        d("perm.ready", "权限就绪，正在侦测…", "Permissions granted, monitoring…");
        d("perm.denied", "权限不足：设置 → 应用 → CellWatch → 权限\n把【位置信息】设为“精确位置”，并允许【电话】，然后重开应用。",
                "Missing permissions: Settings → Apps → CellWatch → Permissions\nSet Location to Precise, allow Phone, then reopen the app.");

        d("sec.device", "── 本机 / SIM ──", "── This device / SIM ──");
        d("sec.serving", "── 服务小区 ──", "── Serving cell ──");
        d("sec.neighbors", "── 邻区排行 ──", "── Neighbors ──");
        d("sec.wifi", "── 周边 WiFi ──", "── Nearby Wi-Fi ──");
        d("sec.net", "── 本机网络 / 标识 ──", "── This device network / IDs ──");
        d("net.none", "（无可用网络接口）", "(no usable interface)");
        d("net.ids", "标识（仅本机）:", "Identifiers (this device only):");
        d("net.hidden_ids", "系统不允许应用读取", "not readable by apps");
        d("net.type.wifi", "WiFi", "Wi-Fi");
        d("net.type.cell", "蜂窝", "cellular");
        d("net.type.other", "其他", "other");
        d("net.prefix.new", "IPv6 前缀 %s（首次记录）", "IPv6 prefix %s (first record)");
        d("net.prefix.changed", "IPv6 前缀 %s（已变化，上次 %s）", "IPv6 prefix %s (changed, was %s)");
        d("net.prefix.same", "IPv6 前缀 %s（与上次一致）", "IPv6 prefix %s (unchanged)");
        d("wifi.count", "热点 %s 个（按信号排序）\n", "Access points: %s (sorted by signal)\n");
        d("wifi.none", "（无扫描结果，或 WLAN 未开启）", "(no scan results, or Wi-Fi is off)");
        d("wifi.open", "开放", "open");
        d("wifi.secured", "加密", "secured");
        d("wifi.wpa3", "WPA3", "WPA3");
        d("wifi.hidden", "<隐藏>", "<hidden>");
        d("sec.events", "── 事件 ──", "── Events ──");

        d("btn.pause", "暂停", "Pause");
        d("btn.resume", "继续", "Resume");
        d("btn.refresh", "立即刷新", "Refresh");
        d("btn.export", "导出CSV", "Export CSV");
        d("btn.share", "分享诊断", "Share report");
        d("btn.clear", "清空事件", "Clear");
        d("btn.mark", "标记场景", "Mark scene");
        d("btn.json", "导出JSON", "Export JSON");
        d("scene.none", "未标记", "no scene");
        d("scene.metro", "地铁", "metro");
        d("scene.mall", "商场", "mall");
        d("scene.office", "写字楼", "office");
        d("scene.outdoor", "户外", "outdoor");
        d("scene.lab", "实验室", "lab");
        d("toast.marked", "已标记：%s", "Marked: %s");
        d("btn.lang", "EN", "中文");

        d("serving.none", "未取得服务小区数据\n（确认位置权限为“精确位置”，且系统定位已开启）",
                "No serving cell data\n(check Location = Precise and system location is on)");
        d("neighbors.count", "邻区 %s 个（按信号排序）\n", "Neighbors: %s (sorted by signal)\n");
        d("trend.prefix", "信号趋势 ", "Signal trend ");
        d("events.none", "（暂无事件）", "(no events yet)");
        d("stats", "采样 %s 次 · 小区记录 %s · 事件 %s", "Samples %s · cells %s · events %s");
        d("stats2", "唯一小区 %s · 场景标记 %s · 当前 %s", "Unique cells %s · markers %s · now %s");
        d("unknown", "未知", "unknown");
        d("signal", "信号", "signal");
        d("init.dots", "初始化…", "Starting…");

        d("toast.store", "存储未就绪", "Storage not ready");
        d("toast.export_fail", "导出失败: %s", "Export failed: %s");
        d("toast.share_fail", "分享失败: %s", "Share failed: %s");
        d("toast.refresh_fail", "刷新失败: %s", "Refresh failed: %s");
        d("share.title", "分享诊断信息", "Share diagnostics");
        d("share.subject", "CellWatch 诊断", "CellWatch diagnostics");

        d("note", "说明：本应用源自 2016 年的开源项目 AIMSICD 0.1.43，并在此基础上重写与扩展；"
                        + "非原创作品，仅供个人研究。Android 10+ 起普通应用无法读取 IMEI/IMSI，也无法读取他人号码——"
                        + "手机号不在空口广播，任何“只收不发”的号码侦测在技术上都不存在。"
                        + "本应用仅基于公开的邻区信息做启发式提醒，请勿用于任何违法用途。",
                "Note: this app is a rewrite/extension of the 2016 open-source project AIMSICD 0.1.43. "
                        + "It is not original work and is meant for personal research only. Since Android 10 ordinary apps "
                        + "cannot read IMEI/IMSI, and nobody's phone number can be read: numbers are not broadcast over the air, "
                        + "so \"receive-only\" number sniffing does not exist. Only public neighbour-cell data is used. Do not use it illegally.");

        // ---- Net ----
        d("net.no_tm", "无电话服务", "No telephony service");
        d("net.operator", "运营商: %s", "Operator: %s");
        d("net.sim_operator", "SIM 运营商: %s", "SIM operator: %s");
        d("net.network", "网络制式: %s", "Network: %s");
        d("net.roaming", "漫游: %s", "Roaming: %s");
        d("net.sim_state", "SIM 状态: %s", "SIM state: %s");
        d("net.own_number", "本机号码: %s", "Own number: %s");
        d("net.not_provided", "系统未提供", "not provided");
        d("net.subs_count", "SIM 卡数量: %s", "SIM cards: %s");
        d("net.card", "卡", "SIM");
        d("net.number", "号码", "number");
        d("net.yes", "是", "yes");
        d("net.no", "否", "no");
        d("net.read_failed", "读取失败: %s", "read failed: %s");
        d("sim.unknown", "未知", "unknown");
        d("sim.absent", "无 SIM 卡", "no SIM");
        d("sim.pin", "PIN 锁定", "PIN locked");
        d("sim.puk", "PUK 锁定", "PUK locked");
        d("sim.netlock", "网络锁定", "network locked");
        d("sim.ready", "SIM 就绪", "ready");
        d("sim.notready", "SIM 未就绪", "not ready");
        d("nettype.2g", "2G", "2G");
        d("nettype.3g", "3G", "3G");
        d("nettype.lte", "4G LTE", "4G LTE");
        d("nettype.ehrpd", "4G eHRPD", "4G eHRPD");
        d("nettype.nr", "5G NR", "5G NR");
        d("nettype.none", "无数据网络", "no data network");
        d("nettype.other", "其他(%s)", "other(%s)");

        // ---- Rules ----
        d("lvl.high", "高", "HIGH");
        d("lvl.mid", "中", "MEDIUM");
        d("lvl.low", "低", "LOW");
        d("lvl.info", "信息", "INFO");

        d("rule.base.kind", "基线", "Baseline");
        d("rule.base.detail", "首次采样 %s", "first sample %s");

        d("rule.lac.kind", "LAC 变化", "LAC change");
        d("rule.lac.detail", "同一小区 CID %s 的 LAC/TAC %s → %s（典型伪基站特征：小区号不变、位置区被改写）",
                "CID %s changed LAC/TAC %s → %s (typical IMSI-catcher trait: same cell id, rewritten location area)");

        d("rule.down.kind", "制式回落", "RAT downgrade");
        d("rule.down.detail", "%s → %s（降级攻击或覆盖边缘的常见特征）",
                "%s → %s (common trait of downgrade attacks or cell-edge coverage)");

        d("rule.up.kind", "制式回升", "RAT upgrade");
        d("rule.up.detail", "%s → %s", "%s → %s");

        d("rule.plmn.kind", "PLMN 变化", "PLMN change");
        d("rule.plmn.detail", "运营商 %s → %s（可能是漫游或伪造网络）",
                "Operator %s → %s (roaming, or a spoofed network)");

        d("rule.neigh.kind", "邻区骤降", "Neighbor collapse");
        d("rule.neigh.detail", "邻区数量 %s → %s", "Neighbor count %s → %s");

        d("rule.spike.kind", "信号骤增", "Signal spike");
        d("rule.spike.detail", "服务小区 %s → %s dBm（近距离强发射？）",
                "Serving cell %s → %s dBm (strong nearby transmitter?)");

        d("rule.jump.kind", "信号突变", "Signal jump");
        d("rule.jump.detail", "服务小区 %s → %s dBm", "Serving cell %s → %s dBm");

        d("rule.lone.kind", "孤岛强信号", "Lone strong cell");
        d("rule.lone.detail", "只剩 1 个小区且信号 %s dBm，邻区全部消失",
                "Only one cell left at %s dBm, all neighbours gone");

        d("rule.2g.kind", "2G 承载", "2G bearer");
        d("rule.2g.detail", "当前工作在 %s，2G 信令加密强度低，注意短信验证码等敏感操作",
                "Running on %s: 2G signalling is weakly protected, beware SMS one-time codes");

        d("rule.pci.kind", "PCI 冲突", "PCI collision");
        d("rule.pci.detail", "PCI/PSC %s 同时出现在两个小区（%s 与 %s）",
                "PCI/PSC %s used by two different cells (%s and %s)");

        d("rule.ping.kind", "频繁切换", "Frequent handover");
        d("rule.ping.detail", "60 秒内服务小区切换 %s 次（乒乓切换）",
                "Serving cell changed %s times within 60 s (ping-pong)");

        d("rule.newlac.kind", "新位置区", "New location area");
        d("rule.newlac.detail", "首次出现 %s，信号 %s dBm", "%s seen for the first time at %s dBm");

        // ---- CrashLog ----
        d("crash.title", "CellWatch 崩溃", "CellWatch crash");
        d("crash.device", "机型: %s %s", "Device: %s %s");
        d("crash.os", "系统: Android %s (API %s)", "OS: Android %s (API %s)");
        d("crash.thread", "线程: %s", "Thread: %s");
    }

    private L() {
    }

    public static void init(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences("cellwatch", Context.MODE_PRIVATE);
            boolean auto = p.getBoolean("auto_lang", true);
            if (auto) {
                String lang = java.util.Locale.getDefault().getLanguage();
                english = !(lang != null && lang.toLowerCase(java.util.Locale.US).startsWith("zh"));
            } else {
                english = p.getBoolean("en", false);
            }
        } catch (Throwable t) {
            english = false;
        }
    }

    public static boolean isEnglish() {
        return english;
    }

    public static void toggle(Context c) {
        english = !english;
        try {
            SharedPreferences.Editor e = c.getSharedPreferences("cellwatch", Context.MODE_PRIVATE).edit();
            e.putBoolean("auto_lang", false);
            e.putBoolean("en", english);
            e.commit();
        } catch (Throwable ignored) {
        }
    }

    public static String t(String key) {
        Map<String, String> m = english ? EN : ZH;
        String v = m.get(key);
        if (v == null) v = ZH.get(key);
        return v == null ? key : v;
    }

    public static String f(String key, Object a) {
        return fmt(t(key), new Object[] { a });
    }

    public static String f(String key, Object a, Object b) {
        return fmt(t(key), new Object[] { a, b });
    }

    public static String f(String key, Object a, Object b, Object c) {
        return fmt(t(key), new Object[] { a, b, c });
    }

    private static String fmt(String pattern, Object[] args) {
        try {
            return String.format(java.util.Locale.US, pattern, args);
        } catch (Throwable t) {
            return pattern;
        }
    }
}
