package com.chatbox.cellwatch;

import android.content.Context;
import android.telephony.TelephonyManager;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads the current cell set using only public framework APIs, via reflection so the
 * app can be compiled against an old android.jar while using whatever the device offers.
 */
public final class Cells {

    public static final int T_UNKNOWN = 0;
    public static final int T_GSM = 1;
    public static final int T_CDMA = 2;
    public static final int T_UMTS = 3;
    public static final int T_LTE = 4;
    public static final int T_NR = 6;

    public static final class Rec {
        public int type = T_UNKNOWN;
        public String klass = "?";
        public String mcc = "?";
        public String mnc = "?";
        public int lac = -1;
        public int cid = -1;
        public int pci = -1;
        public int dbm = -999;
        public int rsrp = -999;
        public int rsrq = -999;
        public int sinr = -999;
        public int earfcn = -1;
        public int ta = -1;
        public String band = "";
        public boolean registered;

        public String plmn() {
            return mcc + "-" + mnc;
        }

        public String typeName() {
            switch (type) {
                case T_GSM: return "2G GSM";
                case T_CDMA: return "2G CDMA";
                case T_UMTS: return "3G UMTS";
                case T_LTE: return "4G LTE";
                case T_NR: return "5G NR";
                default: return L.t("unknown");
            }
        }

        public String key() {
            return type + "/" + mcc + mnc + "/" + lac + "/" + cid;
        }

        public String shortName() {
            return typeName() + " " + plmn() + " L" + lac + " C" + cid + " " + (dbm <= -900 ? "?" : dbm + "dBm");
        }

        public String describe() {
            StringBuilder sb = new StringBuilder();
            sb.append(typeName()).append(' ').append(plmn())
              .append("  LAC/TAC ").append(lac < 0 ? "?" : String.valueOf(lac))
              .append("  CID ").append(cid < 0 ? "?" : String.valueOf(cid));
            if (pci >= 0) sb.append("  PCI/PSC ").append(pci);
            if (dbm > -900) sb.append("  ").append(dbm).append(" dBm");
            if (rsrp > -900) sb.append("  RSRP ").append(rsrp);
            if (rsrq > -900) sb.append("  RSRQ ").append(rsrq);
            if (sinr > -900) sb.append("  SINR ").append(sinr);
            if (band.length() > 0) sb.append("  ").append(band);
            if (earfcn > 0) sb.append("  EARFCN ").append(earfcn);
            if (ta >= 0) sb.append("  TA ").append(ta);
            return sb.toString();
        }
    }

    private Cells() {
    }

    public static List<Rec> read(Context ctx) {
        List<Rec> out = new ArrayList<Rec>();
        try {
            TelephonyManager tm = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return out;
            Object list = invoke(tm.getClass(), tm, "getAllCellInfo");
            if (!(list instanceof List)) return out;
            List raw = (List) list;
            for (int i = 0; i < raw.size(); i++) {
                Object ci = raw.get(i);
                if (ci == null) continue;
                Rec r = new Rec();
                r.klass = simpleName(ci);
                r.registered = Boolean.TRUE.equals(invoke(ci.getClass(), ci, "isRegistered"));
                Object ident = invoke(ci.getClass(), ci, "getCellIdentity");
                Object ss = invoke(ci.getClass(), ci, "getCellSignalStrength");
                if (ss != null) fillSignal(r, ss);
                if (ident != null) fillIdentity(r, ident);
                out.add(r);
            }
        } catch (Throwable t) {
            CrashLog.note("Cells.read: " + t);
        }
        return out;
    }

    private static void fillSignal(Rec r, Object ss) {
        r.dbm = intOf(ss, "getDbm");
        int rsrp = intOf(ss, "getRsrp");
        int rsrq = intOf(ss, "getRsrq");
        int sinr = intOf(ss, "getRssnr");
        if (rsrp > -900) r.rsrp = rsrp;
        if (rsrq > -900) r.rsrq = rsrq;
        if (sinr > -900) r.sinr = sinr;
        int ta = intOf(ss, "getTimingAdvance");
        if (ta >= 0) r.ta = ta;
    }

    private static void fillIdentity(Rec r, Object ident) {
        Class c = ident.getClass();
        // 2G/3G/4G/5G: classify by the CellIdentity implementation first (most reliable)
        String cn = c.getName();
        if (cn.indexOf("Gsm") >= 0) r.type = T_GSM;
        else if (cn.indexOf("Wcdma") >= 0) r.type = T_UMTS;
        else if (cn.indexOf("Lte") >= 0) r.type = T_LTE;
        else if (cn.indexOf("Nr") >= 0) r.type = T_NR;
        else if (cn.indexOf("Cdma") >= 0) r.type = T_CDMA;

        int cid = intOf(ident, "getCid");
        int lac = intOf(ident, "getLac");
        int pci = intOf(ident, "getPci");

        if (cid < 0) {
            cid = intOf(ident, "getCi");
            if (cid >= 0) r.type = T_LTE;
        }
        if (cid < 0) {
            cid = intOf(ident, "getNci");
            if (cid >= 0) r.type = T_NR;
        }
        if (cid < 0 && c.getName().contains("Cdma")) {
            cid = intOf(ident, "getBaseStationId");
            lac = intOf(ident, "getSystemId");
            r.type = T_CDMA;
        }
        if (lac < 0) lac = intOf(ident, "getTac");
        if (pci < 0) pci = intOf(ident, "getPsc");
        if (r.type == T_UNKNOWN) r.type = pci >= 0 ? T_UMTS : T_GSM;

        r.cid = cid;
        r.lac = lac;
        r.pci = pci;

        int earfcn = intOf(ident, "getEarfcn");
        if (earfcn > 0) r.earfcn = earfcn;
        int nrarfcn = intOf(ident, "getNrarfcn");
        if (nrarfcn > 0) r.earfcn = nrarfcn;
        r.band = Band.label(r.type, r.earfcn);

        String mcc = str(ident, "getMccString");
        String mnc = str(ident, "getMncString");
        if (mcc == null) {
            int v = intOf(ident, "getMcc");
            mcc = v > 0 ? String.valueOf(v) : "?";
        }
        if (mnc == null) {
            int v = intOf(ident, "getMnc");
            mnc = v >= 0 ? String.valueOf(v) : "?";
        }
        r.mcc = mcc;
        r.mnc = mnc;
    }

    private static String simpleName(Object o) {
        try {
            String n = o.getClass().getSimpleName();
            return n == null || n.length() == 0 ? o.getClass().getName() : n;
        } catch (Throwable t) {
            return "?";
        }
    }

    static Object invoke(Class c, Object target, String name) {
        try {
            return c.getMethod(name).invoke(target);
        } catch (Throwable t) {
            return null;
        }
    }

    static int intOf(Object o, String name) {
        Object v = invoke(o.getClass(), o, name);
        if (v instanceof Integer) return ((Integer) v).intValue();
        if (v instanceof Long) return (int) (((Long) v).longValue() & 0x7fffffffL);
        return -1;
    }

    private static String str(Object o, String name) {
        Object v = invoke(o.getClass(), o, name);
        return v instanceof String ? (String) v : null;
    }
}
