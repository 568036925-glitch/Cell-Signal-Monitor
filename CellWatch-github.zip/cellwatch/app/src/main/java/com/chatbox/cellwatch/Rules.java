package com.chatbox.cellwatch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Heuristic engine: turns successive cell samples into human-readable observations. */
public final class Rules {

    public static final class Alert {
        public final String level;
        public final String kind;
        public final String detail;

        public Alert(String level, String kind, String detail) {
            this.level = level;
            this.kind = kind;
            this.detail = detail;
        }

        public String line() {
            return "[" + level + "] " + kind + " · " + detail;
        }
    }

    private String lastKey;
    private String lastPlmn;
    private int lastType = -1;
    private int lastLac = -1;
    private int lastDbm = -999;
    private int lastNeighbors = -1;

    private final Map<String, Integer> lacByCid = new HashMap<String, Integer>();
    private final Set<String> seenLac = new HashSet<String>();
    private final List<Long> switches = new ArrayList<Long>();

    public List<Alert> evaluate(Cells.Rec s, List<Cells.Rec> neighbors, List<Cells.Rec> all) {
        List<Alert> out = new ArrayList<Alert>();
        if (s == null) return out;
        long now = System.currentTimeMillis();
        String key = s.key();

        if (lastKey == null) {
            out.add(new Alert(L.t("lvl.info"), L.t("rule.base.kind"), L.f("rule.base.detail", s.describe())));
            remember(s, key, neighbors.size(), now);
            return out;
        }

        Integer prev = lacByCid.get(key);
        if (prev != null && s.lac >= 0 && prev.intValue() != s.lac) {
            out.add(new Alert(L.t("lvl.high"), L.t("rule.lac.kind"),
                    L.f("rule.lac.detail", Integer.valueOf(s.cid), Integer.valueOf(prev.intValue()), Integer.valueOf(s.lac))));
        }

        if (isFast(lastType) && isSlow(s.type)) {
            out.add(new Alert(L.t("lvl.high"), L.t("rule.down.kind"),
                    L.f("rule.down.detail", typeName(lastType), s.typeName())));
        } else if (isSlow(lastType) && isFast(s.type)) {
            out.add(new Alert(L.t("lvl.info"), L.t("rule.up.kind"),
                    L.f("rule.up.detail", typeName(lastType), s.typeName())));
        }

        if (lastPlmn != null && !lastPlmn.equals(s.plmn())) {
            out.add(new Alert(L.t("lvl.high"), L.t("rule.plmn.kind"),
                    L.f("rule.plmn.detail", lastPlmn, s.plmn())));
        }

        if (lastNeighbors >= 4 && neighbors.size() <= lastNeighbors / 3) {
            out.add(new Alert(L.t("lvl.mid"), L.t("rule.neigh.kind"),
                    L.f("rule.neigh.detail", Integer.valueOf(lastNeighbors), Integer.valueOf(neighbors.size()))));
        }

        if (lastDbm > -900 && s.dbm > -900) {
            int d = s.dbm - lastDbm;
            if (d >= 25 && s.dbm > -75) {
                out.add(new Alert(L.t("lvl.high"), L.t("rule.spike.kind"),
                        L.f("rule.spike.detail", Integer.valueOf(lastDbm), Integer.valueOf(s.dbm))));
            } else if (Math.abs(d) >= 20) {
                out.add(new Alert(L.t("lvl.mid"), L.t("rule.jump.kind"),
                        L.f("rule.jump.detail", Integer.valueOf(lastDbm), Integer.valueOf(s.dbm))));
            }
        }

        if (all.size() <= 1 && s.dbm > -75 && lastNeighbors > 0) {
            out.add(new Alert(L.t("lvl.mid"), L.t("rule.lone.kind"),
                    L.f("rule.lone.detail", Integer.valueOf(s.dbm))));
        }

        if ((s.type == Cells.T_GSM || s.type == Cells.T_CDMA) && lastType != s.type) {
            out.add(new Alert(L.t("lvl.mid"), L.t("rule.2g.kind"), L.f("rule.2g.detail", s.typeName())));
        }

        int[] coll = pciCollision(all);
        if (coll != null) {
            out.add(new Alert(L.t("lvl.mid"), L.t("rule.pci.kind"),
                    L.f("rule.pci.detail", Integer.valueOf(coll[0]), Integer.valueOf(coll[1]), Integer.valueOf(coll[2]))));
        }

        if (!key.equals(lastKey)) {
            switches.add(Long.valueOf(now));
        }
        while (!switches.isEmpty() && now - switches.get(0).longValue() > 60000L) {
            switches.remove(0);
        }
        if (switches.size() >= 5) {
            out.add(new Alert(L.t("lvl.mid"), L.t("rule.ping.kind"),
                    L.f("rule.ping.detail", Integer.valueOf(switches.size()))));
            switches.clear();
        }

        String lacId = s.plmn() + "/" + s.lac;
        if (s.lac >= 0 && !seenLac.contains(lacId) && s.dbm > -80) {
            out.add(new Alert(L.t("lvl.low"), L.t("rule.newlac.kind"),
                    L.f("rule.newlac.detail", lacId, Integer.valueOf(s.dbm))));
        }

        remember(s, key, neighbors.size(), now);
        return out;
    }

    private void remember(Cells.Rec s, String key, int neighbors, long now) {
        lastKey = key;
        lastType = s.type;
        lastLac = s.lac;
        lastDbm = s.dbm;
        lastNeighbors = neighbors;
        lastPlmn = s.plmn();
        if (s.lac >= 0) {
            lacByCid.put(key, Integer.valueOf(s.lac));
            seenLac.add(s.plmn() + "/" + s.lac);
        }
    }

    /** @return {pci, prevCellId, cellId} or null */
    private static int[] pciCollision(List<Cells.Rec> all) {
        Map<Integer, int[]> byPci = new HashMap<Integer, int[]>();
        for (int i = 0; i < all.size(); i++) {
            Cells.Rec r = all.get(i);
            if (r.pci < 0) continue;
            Integer p = Integer.valueOf(r.pci);
            int[] prev = byPci.get(p);
            if (prev != null && (prev[1] != r.lac || prev[2] != r.cid)) {
                return new int[] { r.pci, prev[2], r.cid };
            }
            byPci.put(p, new int[] { r.pci, r.lac, r.cid });
        }
        return null;
    }

    private static boolean isFast(int t) {
        return t == Cells.T_LTE || t == Cells.T_NR;
    }

    private static boolean isSlow(int t) {
        return t == Cells.T_GSM || t == Cells.T_CDMA || t == Cells.T_UMTS;
    }

    private static String typeName(int t) {
        switch (t) {
            case Cells.T_GSM: return "2G GSM";
            case Cells.T_CDMA: return "2G CDMA";
            case Cells.T_UMTS: return "3G UMTS";
            case Cells.T_LTE: return "4G LTE";
            case Cells.T_NR: return "5G NR";
            default: return L.t("unknown");
        }
    }
}
