package com.chatbox.cellwatch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * CellWatch 1.2 - root-free cell monitor with heuristic IMSI-catcher hints.
 * Framework only: no third party libraries, no resources, bilingual (zh/en).
 *
 * Derived from the 2016 open-source project AIMSICD 0.1.43 (GPLv3) by way of a
 * clean rewrite; the heuristics and UI here are new. Private research build.
 */
public class MainActivity extends Activity {

    private static final int REQ = 1001;
    private static final String PERM_FINE = "android.permission.ACCESS_FINE_LOCATION";
    private static final String PERM_PHONE = "android.permission.READ_PHONE_STATE";
    private static final char[] BARS = "▁▂▃▄▅▆▇█".toCharArray();

    private final Handler handler = new Handler();
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private final Rules rules = new Rules();
    private final List<String> events = new ArrayList<String>();
    private final List<Integer> trend = new ArrayList<Integer>();

    private boolean running = true;
    private int samples = 0;
    private int sceneIndex = 0;
    private static final String[] SCENES = {
            "scene.none", "scene.metro", "scene.mall", "scene.office", "scene.outdoor", "scene.lab" };

    private Store store;
    private TextView tvStatus;
    private TextView tvSim;
    private TextView tvServing;
    private TextView tvTrend;
    private TextView tvNeighbors;
    private TextView tvWifi;
    private TextView tvNic;
    private TextView tvAlerts;
    private TextView tvStats;
    private Button btnToggle;

    private String lastServingText = "";
    private String lastNeighborText = "";
    private String lastWifiText = "";
    private String lastNicText = "";

    private final Runnable tick = new Runnable() {
        public void run() {
            try {
                sample();
            } catch (Throwable t) {
                CrashLog.note("tick: " + t);
            }
            if (running) handler.postDelayed(this, 3000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        L.init(this);
        CrashLog.install(this);
        try {
            store = new Store(this);
        } catch (Throwable t) {
            CrashLog.note("store: " + t);
        }
        setTitle(L.t("title.app"));
        buildUi();
        if (!hasPermission(PERM_FINE) || !hasPermission(PERM_PHONE)) {
            tvStatus.setText(L.t("perm.requesting"));
            requestPermissions();
        } else {
            startLoop();
            tvStatus.setText(L.t("perm.ready"));
        }
        refreshSim();
        refreshNic();
        updateStats();
    }

    @Override
    protected void onDestroy() {
        running = false;
        handler.removeCallbacks(tick);
        try {
            if (store != null) store.close();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    // ---------- permissions ----------

    private boolean hasPermission(String perm) {
        try {
            Object r = Class.forName("android.content.Context")
                    .getMethod("checkSelfPermission", new Class[] { String.class })
                    .invoke(this, new Object[] { perm });
            return ((Integer) r).intValue() == 0;
        } catch (Throwable t) {
            return true;
        }
    }

    private void requestPermissions() {
        try {
            String[] arr = new String[] { PERM_FINE, "android.permission.ACCESS_COARSE_LOCATION", PERM_PHONE };
            Class.forName("android.app.Activity")
                    .getMethod("requestPermissions", new Class[] { String[].class, Integer.TYPE })
                    .invoke(this, new Object[] { arr, Integer.valueOf(REQ) });
        } catch (Throwable t) {
            CrashLog.note("requestPermissions: " + t);
            startLoop();
        }
    }

    /** Not @Override on purpose: absent from old android.jar. */
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode != REQ) return;
        if (hasPermission(PERM_FINE) && hasPermission(PERM_PHONE)) {
            startLoop();
            tvStatus.setText(L.t("perm.ready"));
        } else {
            tvStatus.setText(L.t("perm.denied"));
            btnToggle.setEnabled(false);
        }
        updateStats();
    }

    private void startLoop() {
        running = true;
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    // ---------- sampling ----------

    private void sample() {
        samples++;
        List<Cells.Rec> all = Cells.read(this);
        Cells.Rec serving = null;
        List<Cells.Rec> neighbors = new ArrayList<Cells.Rec>();
        for (int i = 0; i < all.size(); i++) {
            Cells.Rec r = all.get(i);
            if (r.registered && serving == null) serving = r;
            else neighbors.add(r);
        }

        if (serving == null) {
            lastServingText = L.t("serving.none");
        } else {
            lastServingText = serving.describe();
            addTrend(serving.dbm);
        }
        tvServing.setText(lastServingText);
        tvTrend.setText(trendText());

        Collections.sort(neighbors, new Comparator<Cells.Rec>() {
            public int compare(Cells.Rec a, Cells.Rec b) {
                return b.dbm - a.dbm;
            }
        });
        StringBuilder nb = new StringBuilder();
        nb.append(L.f("neighbors.count", Integer.valueOf(neighbors.size())));
        for (int i = 0; i < neighbors.size() && i < 8; i++) {
            nb.append("· ").append(neighbors.get(i).describe()).append('\n');
        }
        lastNeighborText = nb.toString();
        tvNeighbors.setText(lastNeighborText);

        if (samples % 5 == 1) {
            refreshWifi(true);
        }
        if (samples % 20 == 1) {
            refreshNic();
        }

        List<Rules.Alert> alerts = rules.evaluate(serving, neighbors, all);
        for (int i = 0; i < alerts.size(); i++) {
            addEvent(alerts.get(i));
        }

        if (store != null && samples % 5 == 0) {
            store.addCells(all);
            updateStats();
            if (samples % 30 == 0) refreshSim();
        }
    }

    private void addTrend(int dbm) {
        trend.add(Integer.valueOf(dbm));
        while (trend.size() > 28) trend.remove(0);
    }

    private String trendText() {
        if (trend.isEmpty()) return "";
        StringBuilder sb = new StringBuilder(L.t("trend.prefix"));
        for (int i = 0; i < trend.size(); i++) {
            int dbm = trend.get(i).intValue();
            if (dbm <= -900) {
                sb.append('·');
                continue;
            }
            int idx = (dbm + 120) * 7 / 60;
            if (idx < 0) idx = 0;
            if (idx > 7) idx = 7;
            sb.append(BARS[idx]);
        }
        int last = trend.get(trend.size() - 1).intValue();
        sb.append("  ").append(last <= -900 ? "?" : String.valueOf(last)).append(" dBm");
        return sb.toString();
    }

    private void addEvent(Rules.Alert a) {
        events.add(0, clock.format(new Date()) + "  " + a.line());
        while (events.size() > 60) events.remove(events.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < events.size(); i++) sb.append(events.get(i)).append('\n');
        tvAlerts.setText(sb.toString());
        if (store != null) store.addAlert(a.level, a.kind, a.detail);
    }

    private void refreshWifi(boolean trigger) {
        try {
            List<Wifi.Ap> aps = Wifi.scan(this, trigger);
            if (aps.isEmpty()) {
                lastWifiText = L.t("wifi.none");
                tvWifi.setText(lastWifiText);
                return;
            }
            StringBuilder sb = new StringBuilder(L.f("wifi.count", Integer.valueOf(aps.size())));
            for (int i = 0; i < aps.size() && i < 8; i++) {
                Wifi.Ap a = aps.get(i);
                sb.append("· ").append(a.ssid).append("  ").append(a.level).append(" dBm  ")
                        .append(Wifi.bandOf(a.freq)).append("  ").append(Wifi.securityOf(a)).append('\n')
                        .append("   ").append(a.bssid).append('\n');
            }
            lastWifiText = sb.toString();
            tvWifi.setText(lastWifiText);
        } catch (Throwable t) {
            lastWifiText = String.valueOf(t);
            tvWifi.setText(lastWifiText);
        }
    }

    private void refreshNic() {
        try {
            lastNicText = Nic.summary(this);
            tvNic.setText(lastNicText);
        } catch (Throwable t) {
            lastNicText = String.valueOf(t);
            tvNic.setText(lastNicText);
        }
    }

    private void refreshSim() {
        try {
            tvSim.setText(Net.summary(this));
        } catch (Throwable t) {
            tvSim.setText(L.f("net.read_failed", t));
        }
    }

    private void updateStats() {
        if (tvStats == null) return;
        String c = "?";
        String a = "?";
        String u = "?";
        String m = "?";
        if (store != null) {
            int cc = store.countCells();
            int aa = store.countAlerts();
            int uu = store.uniqueCells();
            int mm = store.countMarkers();
            if (cc >= 0) c = String.valueOf(cc);
            if (aa >= 0) a = String.valueOf(aa);
            if (uu >= 0) u = String.valueOf(uu);
            if (mm >= 0) m = String.valueOf(mm);
        }
        tvStats.setText(L.f("stats", Integer.valueOf(samples), c, a) + "\n"
                + L.f("stats2", u, m, L.t(SCENES[sceneIndex])));
    }

    private void markScene() {
        sceneIndex = (sceneIndex + 1) % SCENES.length;
        String label = L.t(SCENES[sceneIndex]);
        if (sceneIndex != 0 && store != null) store.addMarker(label);
        toast(L.f("toast.marked", label));
        updateStats();
    }

    private void exportJson() {
        if (store == null) {
            toast(L.t("toast.store"));
            return;
        }
        toast(store.exportJson(this));
    }

    // ---------- UI ----------

    private TextView label(String text, int sizeSp, boolean mono) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sizeSp);
        tv.setTextColor(Color.parseColor("#E8EAED"));
        if (mono) tv.setTypeface(Typeface.MONOSPACE);
        tv.setPadding(0, 7, 0, 7);
        return tv;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * getResources().getDisplayMetrics().density);
        col.setPadding(pad, pad, pad, pad);
        col.setBackgroundColor(Color.parseColor("#101316"));

        tvStatus = label(L.t("init.dots"), 13, false);
        tvSim = label("", 13, true);
        tvServing = label("", 14, true);
        tvTrend = label("", 15, true);
        tvNeighbors = label("", 12, true);
        tvWifi = label("", 12, true);
        tvNic = label("", 12, true);
        tvAlerts = label(L.t("events.none"), 12, true);
        tvStats = label("", 12, false);

        col.addView(label(L.t("app.header"), 18, false));
        col.addView(tvStatus);

        col.addView(label(L.t("sec.device"), 14, true));
        col.addView(tvSim);

        col.addView(label(L.t("sec.serving"), 14, true));
        col.addView(tvServing);
        col.addView(tvTrend);

        col.addView(label(L.t("sec.neighbors"), 14, true));
        col.addView(tvNeighbors);

        col.addView(label(L.t("sec.wifi"), 14, true));
        col.addView(tvWifi);

        col.addView(label(L.t("sec.net"), 14, true));
        col.addView(tvNic);

        col.addView(label(L.t("sec.events"), 14, true));
        col.addView(tvAlerts);
        col.addView(tvStats);

        LinearLayout row1 = new LinearLayout(this);
        btnToggle = new Button(this);
        btnToggle.setText(L.t("btn.pause"));
        btnToggle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                running = !running;
                if (running) {
                    startLoop();
                    btnToggle.setText(L.t("btn.pause"));
                } else {
                    handler.removeCallbacks(tick);
                    btnToggle.setText(L.t("btn.resume"));
                }
            }
        });
        Button btnNow = new Button(this);
        btnNow.setText(L.t("btn.refresh"));
        btnNow.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    sample();
                    refreshSim();
                    refreshWifi(true);
                    refreshNic();
                } catch (Throwable t) {
                    toast(L.f("toast.refresh_fail", t));
                }
            }
        });
        Button btnLang = new Button(this);
        btnLang.setText(L.t("btn.lang"));
        btnLang.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                L.toggle(MainActivity.this);
                recreate();
            }
        });
        row1.addView(btnToggle);
        row1.addView(btnNow);
        row1.addView(btnLang);

        LinearLayout row2 = new LinearLayout(this);
        Button btnExport = new Button(this);
        btnExport.setText(L.t("btn.export"));
        btnExport.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (store == null) {
                    toast(L.t("toast.store"));
                    return;
                }
                String path = store.exportCsv(MainActivity.this);
                toast(path);
            }
        });
        Button btnShare = new Button(this);
        btnShare.setText(L.t("btn.share"));
        btnShare.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                share();
            }
        });
        Button btnClear = new Button(this);
        btnClear.setText(L.t("btn.clear"));
        btnClear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                events.clear();
                tvAlerts.setText(L.t("events.none"));
                if (store != null) store.clearAlerts();
                updateStats();
            }
        });
        row2.addView(btnExport);
        row2.addView(btnShare);
        row2.addView(btnClear);

        LinearLayout row3 = new LinearLayout(this);
        Button btnMark = new Button(this);
        btnMark.setText(L.t("btn.mark"));
        btnMark.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                markScene();
            }
        });
        Button btnJson = new Button(this);
        btnJson.setText(L.t("btn.json"));
        btnJson.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                exportJson();
            }
        });
        row3.addView(btnMark);
        row3.addView(btnJson);
        col.addView(row3);

        col.addView(row1);
        col.addView(row2);
        col.addView(label(L.t("note"), 11, false));

        scroll.addView(col);
        setContentView(scroll);
    }

    private void share() {
        try {
            String text = L.t("share.subject") + "\n"
                    + CrashLog.header(this)
                    + "\n" + L.t("sec.device") + "\n" + tvSim.getText()
                    + "\n" + L.t("sec.serving") + "\n" + lastServingText + "\n" + trendText()
                    + "\n" + L.t("sec.neighbors") + "\n" + lastNeighborText
                    + "\n" + L.t("sec.wifi") + "\n" + lastWifiText
                    + "\n" + L.t("sec.net") + "\n" + lastNicText
                    + "\n" + L.t("sec.events") + "\n" + tvAlerts.getText()
                    + (CrashLog.lastCrash() != null && CrashLog.lastCrash().length() > 0
                            ? "\n" + L.t("crash.title") + "\n" + CrashLog.lastCrash() : "");
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, L.t("share.subject"));
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, L.t("share.title")));
        } catch (Throwable t) {
            toast(L.f("toast.share_fail", t));
        }
    }

    private void toast(String msg) {
        try {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        } catch (Throwable ignored) {
        }
    }
}
