package com.chatbox.cellwatch;

/** EARFCN / NR-ARFCN to band name. Small table of the bands actually used in CN/EU/Asia. */
public final class Band {

    private static final int[][] LTE = {
        { 0, 599, 1 }, { 600, 1199, 2 }, { 1200, 1949, 3 }, { 1950, 2399, 4 },
        { 2400, 2649, 5 }, { 2750, 3449, 7 }, { 3450, 3799, 8 }, { 5010, 5179, 12 },
        { 5180, 5279, 13 }, { 5280, 5379, 14 }, { 5730, 5849, 17 }, { 6150, 6449, 20 },
        { 9210, 9659, 28 }, { 36200, 36349, 34 }, { 37750, 38249, 38 }, { 38250, 38649, 39 },
        { 38650, 39649, 40 }, { 39650, 41589, 41 },
    };

    private static final int[][] NR = {
        { 422000, 434000, 1 }, { 361000, 376000, 3 }, { 173800, 178800, 5 },
        { 185000, 192000, 8 }, { 151600, 160600, 28 }, { 499200, 537999, 41 },
        { 620000, 653333, 78 }, { 620000, 680000, 77 }, { 693334, 733333, 79 },
        { 2016667, 2070832, 257 }, { 2070833, 2084999, 258 },
    };

    private Band() {
    }

    public static int lteBand(int earfcn) {
        if (earfcn < 0) return -1;
        for (int i = 0; i < LTE.length; i++) {
            if (earfcn >= LTE[i][0] && earfcn <= LTE[i][1]) return LTE[i][2];
        }
        return -1;
    }

    public static int nrBand(int arfcn) {
        if (arfcn < 0) return -1;
        for (int i = 0; i < NR.length; i++) {
            if (arfcn >= NR[i][0] && arfcn <= NR[i][1]) return NR[i][2];
        }
        return -1;
    }

    /** "LTE B3" / "NR n78" or "" when unknown. */
    public static String label(int type, int earfcn) {
        if (earfcn <= 0) return "";
        if (type == Cells.T_LTE) {
            int b = lteBand(earfcn);
            return b < 0 ? "" : "B" + b;
        }
        if (type == Cells.T_NR) {
            int b = nrBand(earfcn);
            return b < 0 ? "" : "n" + b;
        }
        return "";
    }
}
