package com.chatbox.cellwatch;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;

/** History store (cells + alerts) and CSV export. */
public final class Store extends SQLiteOpenHelper {

    private static final int V = 3;

    public Store(Context c) {
        super(c, "cellwatch.db", null, V);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        create(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL("DROP TABLE IF EXISTS cells");
            db.execSQL("DROP TABLE IF EXISTS alerts");
        } catch (Throwable ignored) {
        }
        create(db);
    }

    private void create(SQLiteDatabase db) {
        try {
            db.execSQL("CREATE TABLE IF NOT EXISTS cells (ts INTEGER, kind INTEGER, label TEXT, mcc TEXT, mnc TEXT,"
                    + " lac INTEGER, cid INTEGER, pci INTEGER, dbm INTEGER, rsrp INTEGER, rsrq INTEGER,"
                    + " sinr INTEGER, earfcn INTEGER, ta INTEGER, reg INTEGER)");
            db.execSQL("CREATE TABLE IF NOT EXISTS alerts (ts INTEGER, level TEXT, kind TEXT, detail TEXT)");
            db.execSQL("CREATE TABLE IF NOT EXISTS markers (ts INTEGER, scene TEXT)");
        } catch (Throwable t) {
            CrashLog.note("Store.create " + t);
        }
    }

    public void addCells(java.util.List<Cells.Rec> list) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            long now = System.currentTimeMillis();
            for (int i = 0; i < list.size(); i++) {
                Cells.Rec r = list.get(i);
                db.execSQL("INSERT INTO cells VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        new Object[] { Long.valueOf(now), Integer.valueOf(r.type), r.klass, r.mcc, r.mnc,
                                Integer.valueOf(r.lac), Integer.valueOf(r.cid), Integer.valueOf(r.pci),
                                Integer.valueOf(r.dbm), Integer.valueOf(r.rsrp), Integer.valueOf(r.rsrq),
                                Integer.valueOf(r.sinr), Integer.valueOf(r.earfcn), Integer.valueOf(r.ta),
                                Integer.valueOf(r.registered ? 1 : 0) });
            }
        } catch (Throwable t) {
            CrashLog.note("Store.addCells " + t);
        }
    }

    public void addAlert(String level, String kind, String detail) {
        try {
            getWritableDatabase().execSQL("INSERT INTO alerts VALUES (?,?,?,?)",
                    new Object[] { Long.valueOf(System.currentTimeMillis()), level, kind, detail });
        } catch (Throwable t) {
            CrashLog.note("Store.addAlert " + t);
        }
    }

    public void addMarker(String scene) {
        try {
            getWritableDatabase().execSQL("INSERT INTO markers VALUES (?,?)",
                    new Object[] { Long.valueOf(System.currentTimeMillis()), scene });
        } catch (Throwable t) {
            CrashLog.note("Store.addMarker " + t);
        }
    }

    public int countMarkers() {
        return count("markers");
    }

    public int uniqueCells() {
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM (SELECT DISTINCT kind,mcc,mnc,lac,cid FROM cells)", null);
            if (c.moveToFirst()) return c.getInt(0);
        } catch (Throwable t) {
            CrashLog.note("Store.uniqueCells " + t);
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    /** Machine-readable dump for the paper's analysis script. */
    public String exportJson(Context ctx) {
        File dir = outDir(ctx);
        if (dir == null) return "无法写入存储";
        File out = new File(dir, "cellwatch-" + System.currentTimeMillis() + ".json");
        PrintWriter w = null;
        Cursor c = null;
        try {
            w = new PrintWriter(new FileOutputStream(out), true);
            w.println("{");
            w.println("  \"app\": \"CellWatch 1.4\",");
            w.println("  \"exportedAt\": " + System.currentTimeMillis() + ",");
            w.println("  \"device\": {\"maker\": \"" + esc(android.os.Build.MANUFACTURER) + "\", \"model\": \""
                    + esc(android.os.Build.MODEL) + "\", \"api\": " + android.os.Build.VERSION.SDK_INT + "},");

            w.println("  \"cells\": [");
            c = getReadableDatabase().rawQuery(
                    "SELECT ts,kind,label,mcc,mnc,lac,cid,pci,dbm,rsrp,rsrq,sinr,earfcn,ta,reg FROM cells ORDER BY ts", null);
            boolean first = true;
            while (c.moveToNext()) {
                if (!first) w.println(",");
                first = false;
                w.print("    {\"ts\":" + c.getLong(0)
                        + ",\"rat\":" + c.getInt(1)
                        + ",\"mcc\":\"" + esc(c.getString(3)) + "\""
                        + ",\"mnc\":\"" + esc(c.getString(4)) + "\""
                        + ",\"lac\":" + c.getInt(5)
                        + ",\"cid\":" + c.getInt(6)
                        + ",\"pci\":" + c.getInt(7)
                        + ",\"dbm\":" + c.getInt(8)
                        + ",\"rsrp\":" + c.getInt(9)
                        + ",\"rsrq\":" + c.getInt(10)
                        + ",\"sinr\":" + c.getInt(11)
                        + ",\"earfcn\":" + c.getInt(12)
                        + ",\"ta\":" + c.getInt(13)
                        + ",\"registered\":" + (c.getInt(14) == 1) + "}");
            }
            c.close();
            c = null;
            w.println();
            w.println("  ],");

            w.println("  \"alerts\": [");
            c = getReadableDatabase().rawQuery("SELECT ts,level,kind,detail FROM alerts ORDER BY ts", null);
            first = true;
            while (c.moveToNext()) {
                if (!first) w.println(",");
                first = false;
                w.print("    {\"ts\":" + c.getLong(0) + ",\"level\":\"" + esc(c.getString(1))
                        + "\",\"kind\":\"" + esc(c.getString(2)) + "\",\"detail\":\"" + esc(c.getString(3)) + "\"}");
            }
            c.close();
            c = null;
            w.println();
            w.println("  ],");

            w.println("  \"markers\": [");
            c = getReadableDatabase().rawQuery("SELECT ts,scene FROM markers ORDER BY ts", null);
            first = true;
            while (c.moveToNext()) {
                if (!first) w.println(",");
                first = false;
                w.print("    {\"ts\":" + c.getLong(0) + ",\"scene\":\"" + esc(c.getString(1)) + "\"}");
            }
            w.println();
            w.println("  ]");
            w.println("}");
            return out.getAbsolutePath();
        } catch (Throwable t) {
            return "导出失败: " + t;
        } finally {
            try {
                if (c != null) c.close();
            } catch (Throwable ignored) {
            }
            try {
                if (w != null) w.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static File outDir(Context ctx) {
        File dir = null;
        try {
            dir = ctx.getExternalFilesDir(null);
        } catch (Throwable ignored) {
        }
        if (dir == null) {
            try {
                dir = ctx.getFilesDir();
            } catch (Throwable ignored) {
            }
        }
        return dir;
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
    }

    public void clearAlerts() {
        try {
            getWritableDatabase().execSQL("DELETE FROM alerts");
        } catch (Throwable t) {
            CrashLog.note("Store.clearAlerts " + t);
        }
    }

    public int countCells() {
        return count("cells");
    }

    public int countAlerts() {
        return count("alerts");
    }

    private int count(String table) {
        Cursor c = null;
        try {
            c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table, null);
            if (c.moveToFirst()) return c.getInt(0);
        } catch (Throwable t) {
            CrashLog.note("Store.count " + t);
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    public String exportCsv(Context ctx) {
        File dir = null;
        try {
            dir = ctx.getExternalFilesDir(null);
        } catch (Throwable ignored) {
        }
        if (dir == null) {
            try {
                dir = ctx.getFilesDir();
            } catch (Throwable ignored) {
            }
        }
        if (dir == null) return "无法写入存储";
        File out = new File(dir, "cellwatch-" + System.currentTimeMillis() + ".csv");
        PrintWriter w = null;
        Cursor c = null;
        try {
            w = new PrintWriter(new FileOutputStream(out), true);
            w.println("ts,kind,label,mcc,mnc,lac,cid,pci,dbm,rsrp,rsrq,sinr,earfcn,ta,registered");
            c = getReadableDatabase().rawQuery(
                    "SELECT ts,kind,label,mcc,mnc,lac,cid,pci,dbm,rsrp,rsrq,sinr,earfcn,ta,reg FROM cells ORDER BY ts", null);
            while (c.moveToNext()) {
                StringBuilder sb = new StringBuilder();
                sb.append(c.getLong(0)).append(',')
                  .append(c.getInt(1)).append(',')
                  .append(c.getString(2)).append(',')
                  .append(c.getString(3)).append(',')
                  .append(c.getString(4));
                for (int i = 5; i <= 14; i++) sb.append(',').append(c.getInt(i));
                w.println(sb.toString());
            }
            c.close();
            c = null;
            w.println();
            w.println("# alerts,ts,level,kind,detail");
            c = getReadableDatabase().rawQuery("SELECT ts,level,kind,detail FROM alerts ORDER BY ts", null);
            while (c.moveToNext()) {
                w.println(c.getLong(0) + "," + c.getString(1) + "," + c.getString(2) + ","
                        + "\"" + safe(c.getString(3)) + "\"");
            }
            return out.getAbsolutePath();
        } catch (Throwable t) {
            return "导出失败: " + t;
        } finally {
            try {
                if (c != null) c.close();
            } catch (Throwable ignored) {
            }
            try {
                if (w != null) w.close();
            } catch (Throwable ignored) {
            }
        }
    }

    private static String safe(String s) {
        return s == null ? "" : s.replace('"', '\'');
    }
}
