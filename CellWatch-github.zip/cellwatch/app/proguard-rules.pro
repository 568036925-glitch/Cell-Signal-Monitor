﻿# Keep reflection targets used by Cells.java
-keep class com.chatbox.cellwatch.** { *; }
