# Changelog

所有版本均为**个人研究用**构建，不通过任何应用商店分发。

## 1.5
- 新增「本机网络 / 标识」面板：逐接口显示 IPv4 / IPv6
- 新增 **IPv6 /64 前缀追踪**：与上次会话比对，标注「首次记录 / 已变化 / 与上次一致」
- 显示 Android ID、Build 指纹；明确标注 IMEI/IMSI 系统不允许应用读取

## 1.4
- 研究模式：**场景标记**（地铁 / 商场 / 写字楼 / 户外 / 实验室）
- **JSON 结构化导出**（含 rat/mcc/mnc/lac/cid/pci/dbm/rsrp/rsrq/sinr/earfcn/ta/registered）
- 统计面板增加「唯一小区数 / 场景标记数 / 当前场景」
- 配套 `analyze.mjs`：JSON → 论文可直接引用的 Markdown 指标表

## 1.3
- **全制式识别**：2G GSM / 2G CDMA / 3G UMTS / 4G LTE / 5G NR 分开标注（先按 CellIdentity 实现类判定，再字段兜底）
- 新增 `Band.java`：由 EARFCN / NR-ARFCN 反查频段（LTE B1/B3/B5/B8/B34/B38/B39/B40/B41，NR n1/n3/n5/n8/n28/n41/n77/n78/n79）
- 新增 **周边 WiFi 扫描**：SSID / BSSID / dBm / 频段 / 开放或加密（WPA3 识别）
- 新增权限：`ACCESS_WIFI_STATE`、`CHANGE_WIFI_STATE`、`ACCESS_NETWORK_STATE`（普通权限）

## 1.2
- **中英双语** + 运行时语言切换（默认跟随系统语言，选择会记住）
- 新增完整 **MANUAL.md**（中文 + English）
- 明确「非原创来源声明」与「私密自用、不滥用声明」

## 1.1
- LTE 增加 RSRP / RSRQ / SINR / EARFCN / TA
- 邻区按信号排序（前 8）；信号趋势迷你曲线
- 本机 / SIM 信息面板（运营商、PLMN、漫游、SIM 状态、本机号码、双卡列表）
- 启发式规则 5 条 → **12 条**，分高 / 中 / 低 / 信息四级
- CSV 导出扩展到 15 字段；支持清空事件、立即刷新

## 1.0
- 首个可运行版本：服务小区与邻区读取、5 条启发式规则、SQLite 历史、CSV 导出、崩溃记录

---

## 明确不提供的功能

以下能力**不在本项目范围内**，也不接受任何形式的定制请求：

- 射频发射、模拟基站（eNB/gNB）、诱骗终端接入
- 采集他人 IMSI / IMEI / 手机号
- 枚举邻区设备、获取他人 IP
- 获取他人 WiFi 密码、破解凭据

原因：蜂窝链路由闭源基带固件控制，应用层无发射接口；号码与 IMSI 的映射只存在于运营商核心网；
上述行为在绝大多数司法辖区构成刑事犯罪。详见 [MANUAL.md](MANUAL.md) 第 3、7 节。
