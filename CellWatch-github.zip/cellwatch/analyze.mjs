#!/usr/bin/env node
/**
 * CellWatch 数据分析脚本（论文/作品用）
 * 用法: node analyze.mjs cellwatch-1730000000.json
 *
 * 输出: 可直接贴进论文的 Markdown 指标表
 * 说明: 只统计基站参数与本地事件，不涉及任何个人信息。
 */
import fs from 'fs';

const path = process.argv[2];
if (!path) {
  console.error('用法: node analyze.mjs <cellwatch-xxx.json>');
  process.exit(1);
}

const d = JSON.parse(fs.readFileSync(path, 'utf8'));
const cells = d.cells || [];
const alerts = d.alerts || [];
const markers = d.markers || [];

const RAT = { 0: 'unknown', 1: '2G GSM', 2: '2G CDMA', 3: '3G UMTS', 4: '4G LTE', 6: '5G NR' };

if (cells.length === 0) {
  console.log('数据为空');
  process.exit(0);
}

const t0 = cells[0].ts;
const t1 = cells[cells.length - 1].ts;
const minutes = Math.max(1, Math.round((t1 - t0) / 60000));
const samples = new Set(cells.map((c) => c.ts)).size;

// 唯一小区
const key = (c) => `${c.rat}/${c.mcc}${c.mnc}/${c.lac}/${c.cid}`;
const uniq = new Map();
for (const c of cells) if (!uniq.has(key(c))) uniq.set(key(c), c);

// 按制式
const byRat = {};
for (const c of uniq.values()) byRat[c.rat] = (byRat[c.rat] || 0) + 1;

// 服务小区序列
const serving = [];
let lastKey = null;
for (const c of cells) {
  if (!c.registered) continue;
  const k = key(c);
  if (k !== lastKey) {
    serving.push({ ts: c.ts, k, c });
    lastKey = k;
  }
}

// 事件
const byLevel = {};
const byKind = {};
for (const a of alerts) {
  byLevel[a.level] = (byLevel[a.level] || 0) + 1;
  byKind[a.kind] = (byKind[a.kind] || 0) + 1;
}

const sig = cells.filter((c) => c.registered && c.dbm > -900).map((c) => c.dbm);
const mean = sig.length ? sig.reduce((a, b) => a + b, 0) / sig.length : NaN;
const sd = sig.length > 1
  ? Math.sqrt(sig.reduce((a, b) => a + (b - mean) ** 2, 0) / (sig.length - 1))
  : NaN;

console.log('# CellWatch 采集摘要\n');
console.log(`- 设备: ${d.device.maker} ${d.device.model} (API ${d.device.api})`);
console.log(`- 采集时段: ${new Date(t0).toLocaleString()} → ${new Date(t1).toLocaleString()} (${minutes} 分钟)`);
console.log(`- 采样批次数: ${samples}，小区记录 ${cells.length} 条`);
console.log(`- 唯一小区: ${uniq.size} 个；服务小区切换 ${serving.length - 1} 次`);
if (markers.length) {
  console.log(`- 场景标记: ${markers.map((m) => m.scene).join(' / ')}`);
}

console.log('\n## 表 1 唯一小区按制式分布\n');
console.log('| 制式 | 唯一小区数 | 占比 |');
console.log('|---|---|---|');
for (const r of Object.keys(byRat).sort((a, b) => a - b)) {
  console.log(`| ${RAT[r] || r} | ${byRat[r]} | ${((byRat[r] / uniq.size) * 100).toFixed(1)}% |`);
}

console.log('\n## 表 2 服务小区信号统计 (dBm)\n');
console.log('| 指标 | 值 |');
console.log('|---|---|');
console.log(`| 样本数 | ${sig.length} |`);
console.log(`| 均值 | ${mean.toFixed(1)} |`);
console.log(`| 标准差 | ${sd.toFixed(1)} |`);
console.log(`| 最小 / 最大 | ${Math.min(...sig)} / ${Math.max(...sig)} |`);

console.log('\n## 表 3 事件统计\n');
console.log('| 等级 | 次数 | 每小时 |');
console.log('|---|---|---|');
for (const l of Object.keys(byLevel)) {
  console.log(`| ${l} | ${byLevel[l]} | ${((byLevel[l] / minutes) * 60).toFixed(2)} |`);
}
console.log('\n| 规则 | 次数 |');
console.log('|---|---|');
for (const k of Object.keys(byKind).sort((a, b) => byKind[b] - byKind[a])) {
  console.log(`| ${k} | ${byKind[k]} |`);
}

const high = byLevel['高'] || byLevel['HIGH'] || 0;
console.log('\n## 关键指标（可直接引用）\n');
console.log(`- 异常事件密度: ${((alerts.length / minutes) * 60).toFixed(2)} 次/小时`);
console.log(`- 高等级事件密度: ${((high / minutes) * 60).toFixed(2)} 次/小时`);
console.log(`- 小区切换率: ${((serving.length - 1) / minutes * 60).toFixed(2)} 次/小时`);
console.log(`- 每小区平均采样: ${(cells.length / uniq.size).toFixed(1)} 条`);
console.log('\n> 注意: 以上为观测统计，不代表已确认的伪基站。论文中应明确区分'
  + '"可观测异常"与"确证攻击"，并讨论误报来源（切换、弱覆盖、载波聚合等）。');
