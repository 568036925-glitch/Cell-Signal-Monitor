# CellWatch 1.2 使用说明书 / User Manual

> **本文件为双语：中文在前，English below.**

---

# 中文版

## 0. 关于本项目（请先读这一段）

**这不是原创作品。** CellWatch 是在一个**十年前（2016 年）的开源项目**基础上的重写版本：

| 项目 | 说明 |
|---|---|
| 原始项目 | **AIMSICD — Android IMSI-Catcher Detector**（作者 SecUpwN 等，版本 v0.1.43-alpha，GPLv3） |
| 原始项目状态 | 已停止维护，最后更新约 2016–2017 年 |
| 本应用关系 | 重新实现的界面与侦测逻辑，**在其功能构想上扩展**；源码为新编写，未直接复制原项目代码 |
| 本应用新增 | 在现代 Android（10–14）上可用的取数路径、12 条启发式侦测规则、双语界面、趋势曲线、CSV 导出 |
| 许可 | 本重写代码采用 MIT；若你要复用 AIMSICD 的原始代码或资源，那部分**必须**遵守 GPLv3 |

原项目地址（供溯源与致谢）：`CellularPrivacy/Android-IMSI-Catcher-Detector`

**这是一个私密自用版本（private build）**，由使用者自行构建/安装，不通过任何应用商店分发，
不代表原项目官方，也不代表任何厂商。使用者声明：**仅用于个人的网络环境自查与研究，不用于滥用。**

## 1. 它能做什么

每 3 秒采样一次系统的公开小区信息（`getAllCellInfo()`）：

- **服务小区**：制式、MCC-MNC(PLMN)、LAC/TAC、CID、PCI/PSC、信号 dBm；
  LTE 额外显示 RSRP / RSRQ / SINR / EARFCN / TA；由 EARFCN/NRARFCN 推算**频段**（如 LTE B3、NR n78）
- **全制式识别**：2G GSM/CDMA、3G UMTS、4G LTE、5G NR 分别标注，不再混淆
- **周边 WiFi**：SSID / BSSID / 信号 dBm / 2.4G–5G–6G 频段 / 开放或加密（含 WPA3 识别），按信号排序前 8
- **邻区排行**：按信号强度排序，显示前 8 个
- **信号趋势**：最近 28 次采样的迷你曲线（▁▂▃▄▅▆▇█）
- **本机 / SIM 信息**：运营商、SIM 运营商(MCC-MNC)、数据网络制式、漫游状态、
  SIM 状态、本机号码（系统提供时）、双卡列表
- **事件日志**：12 条规则命中时记录，分 高 / 中 / 低 / 信息 四级
- **CSV 导出**：15 个字段的小区历史 + 事件
- **分享诊断**：一键分享当前状态、事件与崩溃信息
- **语言切换**：右上角按钮在 中文 / English 之间切换（默认跟随系统语言）

## 2. 伪基站相关的侦测规则（本版重点）

> 这些是**启发式提示**，不是"确凿判定"。真正的判定需要基带层数据，那需要 root 与特定硬件。

| # | 规则 | 等级 | 含义 |
|---|---|---|---|
| 1 | 同一 CID 的 LAC/TAC 变化 | 高 | 伪基站常保留小区号但改写位置区 |
| 2 | 4G/5G → 2G/3G 回落 | 高 | 降级攻击、或覆盖边缘的典型特征 |
| 3 | PLMN（运营商）变化 | 高 | 漫游，或伪造网络 |
| 4 | 信号骤增（≥25 dBm 且 > -75） | 高 | 附近出现强发射源 |
| 5 | 邻区骤降 | 中 | 周边小区突然消失，可能被压制/屏蔽 |
| 6 | 信号突变（≥20 dBm） | 中 | 短时大幅波动 |
| 7 | 孤岛强信号 | 中 | 只剩 1 个小区且信号很强 |
| 8 | 2G 承载 | 中 | 2G 信令加密弱，注意短信验证码等 |
| 9 | PCI/PSC 冲突 | 中 | 两个不同小区用了同一 PCI |
| 10 | 60 秒内切换 ≥5 次 | 中 | 乒乓切换，可能被反复重定向 |
| 11 | 新位置区首次出现 | 低 | 首次看到的 PLMN/LAC 组合 |
| 12 | 制式回升 | 信息 | 仅记录 |

## 3. 它做不到什么（平台限制，非代码问题）

| 能力 | 原因 |
|---|---|
| 读取**他人手机号** | 手机号不在空口广播；只有伪装基站（IMSI Catcher）才可能获得，属监听通信，违法 |
| **发射信号 / 模拟基站** | 手机蜂窝射频由闭源基带固件控制，应用层（含 root）无发射接口；且需频谱许可。本项目**明确不提供**任何发射、诱骗接入、采集他人号码的能力 |
| 读取 IMEI / IMSI / SIM 序列号 | Android 10 起普通应用被彻底禁止 |
| 读取基带 / AT 命令 / `/dev/diag` | 需 root + 特定基带固件 |
| 上传/查询 OpenCellID | 官方旧接口已于 2017 年关停 |
| 后台常驻监控 | 本版为前台运行；退到后台可能被系统限制采样 |

## 4. 使用步骤

1. 安装 APK（若已装旧版，同签名可直接覆盖；不同签名须先卸载）；
2. 首次启动会申请权限：**位置信息必须选"精确位置"**，并允许**电话**；
3. 主界面即开始采样（3 秒一次）；
4. 底部按钮：暂停/继续、立即刷新、EN/中文、导出CSV、分享诊断、清空事件；
5. 若长时间无数据：到 设置 → 应用 → CellWatch → 权限 检查是否被降级为"大致位置"。

## 5. 隐私说明

- 应用**不联网**（清单里没有任何网络权限），数据全部留在本机；
- SQLite 历史存于应用私有目录；CSV 导出到应用外部私有目录
  （`Android/data/com.chatbox.cellwatch/files/`）；
- 无遥测、无统计、无第三方 SDK。

## 6. 论文 / 参赛作品使用建议（合规路径）

这个选题不靠"灰色地带"也能立住，关键是**立题方式**。推荐：

> “基于公开 Android API 的蜂窝网络异常观测：方法与误报率分析”
> 被动测量研究，不发射、不采集个人信息，可复现。

**为什么这个立题更强**
- 审稿人会问的第一个问题就是“为什么不用 IMSI 层面数据”——公开 API 的**限制本身就是论文动机**，而不是缺陷；
- 可以量化“在受限观测条件下能发现什么、误报多少”，这是真实贡献；
- 可复现：工具 + 数据 + 脚本全部公开。

**采集协议（建议直接写进方法论）**
1. 场景分组：地铁 / 商场 / 写字楼 / 户外 / 实验室，每一组 ≥ 3 次独立采集，每次 ≥ 10 分钟；
2. 每次采集前点一下【标记场景】，数据里就带上了时间戳与场景，`analyze.mjs` 会自动分组统计；
3. 对照组：同一地点用第二台手机（不同运营商）并行采集，用于区分“网络问题”与“观测伪影”；
4. 导出 `导出JSON` → 用 `analyze.mjs` 生成表格。

**伦理与合规声明（建议写进论文）**
- 仅接收基站广播参数（PLMN/LAC/CID/PCI/信号），不发射任何信号；
- 不采集 IMSI/IMEI/号码/位置轨迹，不涉及个人信息，无需知情同意；
- 应用无网络权限，数据不出设备；
- 遵循当地无线电与隐私法规。

**开源合规（必须写）**
- 本工具派生自 AIMSICD 0.1.43（GPLv3），需在论文与仓库中声明并附上游链接；
- 本项目新增代码采用 MIT；若发布修改后的 APK，需同时提供完整源码。

**不要写的表述**（审稿人一眼看出问题）
- “本工具可以检测伪基站”——应写“检测可观测异常，并评估误报率”；
- “无法解释的小区突然出现即是攻击”——应作为待验证假设，并给出反例分析。

## 7. 自行构建与签名

```bash
# 1) 打开工程（Android Studio，AGP 8.x / JDK 17）
./gradlew assembleRelease

# 2) 生成你自己的发布密钥（务必离线备份）
keytool -genkeypair -v -keystore cellwatch.jks -alias cellwatch \
        -keyalg RSA -keysize 2048 -validity 10000

# 3) 签名
apksigner sign --ks cellwatch.jks --out CellWatch.apk app-release-unsigned.apk
```

> 更新版本必须使用**同一个** keystore，否则系统会判定签名冲突而拒绝安装。

## 7. 法律与使用边界（重要）

- 本应用只读取**本机**已授权的系统公开信息；不发射任何无线信号，不伪装基站，不干扰通信；
- **严禁**用于：窃听他人通信、截取他人号码/短信、诈骗、干扰公共网络；
  这些行为在绝大多数国家和地区构成刑事犯罪；
- 你所在辖区对"无线电侦测/监听"有专门立法（如中国《无线电管理条例》《网络安全法》），
  使用前请自行确认合法性；
- 本软件按 MIT 许可"按现状"提供，不附带任何担保；使用风险由使用者自负。

---

# English

## 0. About this project (read first)

**This is not original work.** CellWatch is a rewrite of an open-source project from
**about ten years ago (2016)**:

| Item | Detail |
|---|---|
| Upstream | **AIMSICD — Android IMSI-Catcher Detector** (by SecUpwN et al., v0.1.43-alpha, GPLv3) |
| Upstream status | Abandoned; last activity around 2016–2017 |
| Relation | Re-implemented UI and detection logic, **extending the original concept**; source is newly written, not copied |
| Added here | Working data path on modern Android (10–14), 12 heuristic rules, bilingual UI, trend sparkline, CSV export |
| License | This rewrite is MIT; reusing upstream AIMSICD code/assets **requires** GPLv3 compliance |

Upstream: `CellularPrivacy/Android-IMSI-Catcher-Detector` (credited, not affiliated).

**This is a private build.** Built and installed by the user, not distributed through any store,
not affiliated with the upstream project or any vendor. The user states it is for **personal
self-check and research only, and will not be abused.**

## 1. What it does

Samples public cell info (`getAllCellInfo()`) every 3 seconds:

- **服务小区**: RAT, MCC-MNC (PLMN), LAC/TAC, CID, PCI/PSC, dBm;
  for LTE also RSRP / RSRQ / SINR / EARFCN / TA, plus **band** derived from EARFCN/NRARFCN (e.g. LTE B3, NR n78)
- **All RATs recognised**: 2G GSM/CDMA, 3G UMTS, 4G LTE, 5G NR are labelled separately
- **Nearby Wi-Fi**: SSID / BSSID / dBm / 2.4G–5G–6G band / open-or-encrypted (WPA3 aware), top 8 by signal
- **Neighbor ranking**: sorted by signal, top 8
- **Signal trend**: sparkline of the last 28 samples (▁▂▃▄▅▆▇█)
- **Device / SIM**: operator, SIM operator (MCC-MNC), data network, roaming,
  SIM state, own number (if the OS provides it), dual-SIM list
- **Event log**: 12 rules, graded HIGH / MEDIUM / LOW / INFO
- **CSV export**: 15 fields of cell history plus events
- **Share report**: one tap to share state, events and last crash
- **Language switch**: 中文 / English (follows system locale by default)

## 2. IMSI-catcher heuristics (the point of this build)

> These are **hints**, not proof. Real detection needs baseband data, which needs root and
> specific hardware. No app can do it with public APIs.

| # | Rule | Level | Meaning |
|---|---|---|---|
| 1 | Same CID changed LAC/TAC | HIGH | Catchers often keep the cell id but rewrite the location area |
| 2 | 4G/5G → 2G/3G downgrade | HIGH | Typical of downgrade attacks or cell-edge coverage |
| 3 | PLMN change | HIGH | Roaming, or a spoofed network |
| 4 | Signal spike (≥25 dBm and > -75) | HIGH | A strong transmitter appeared nearby |
| 5 | Neighbor collapse | MEDIUM | Surrounding cells vanished (suppressed?) |
| 6 | Signal jump (≥20 dBm) | MEDIUM | Large short-term swing |
| 7 | Lone strong cell | MEDIUM | Only one cell left, unusually strong |
| 8 | 2G bearer | MEDIUM | Weak 2G signalling protection; watch OTPs |
| 9 | PCI/PSC collision | MEDIUM | Two different cells share one PCI |
| 10 | ≥5 handovers in 60 s | MEDIUM | Ping-pong redirection |
| 11 | New location area | LOW | First sighting of a PLMN/LAC pair |
| 12 | RAT upgrade | INFO | Recorded only |

## 3. What it cannot do (platform limits, not code)

| Capability | Why |
|---|---|
| Read **other people's phone numbers** | Numbers are never broadcast over the air; only a fake base station (IMSI catcher) could try, which is unlawful interception |
| **Transmit / impersonate a base station** | The cellular radio is driven by closed modem firmware; no app-level (or root) transmit API exists, and a spectrum licence would be required. This project **provides no transmit, attach-hijacking or number-harvesting capability at all** |
| Read IMEI / IMSI / SIM serial | Blocked for ordinary apps since Android 10 |
| Read baseband / AT commands / `/dev/diag` | Requires root and specific modem firmware |
| OpenCellID upload/lookup | The legacy endpoint was shut down in 2017 |
| Background monitoring | Foreground only; the OS may throttle when backgrounded |

## 4. Usage

1. Install the APK (same signature = in-place update; different signature = uninstall first);
2. On first launch grant permissions: **Location must be “Precise”**, and allow **Phone**;
3. Sampling starts immediately (every 3 s);
4. Bottom buttons: Pause/Resume, Refresh, EN/中文, Export CSV, Share report, Clear;
5. No data for a long time? Check Settings → Apps → CellWatch → Permissions
   (make sure Location was not downgraded to “Approximate”).

## 5. Privacy

- The app has **no network permission** — nothing leaves the device;
- SQLite history stays in app-private storage; CSV goes to
  `Android/data/com.chatbox.cellwatch/files/`;
- No telemetry, no analytics, no third-party SDK.

## 6. Build it yourself

```bash
./gradlew assembleRelease
keytool -genkeypair -v -keystore cellwatch.jks -alias cellwatch \
        -keyalg RSA -keysize 2048 -validity 10000
apksigner sign --ks cellwatch.jks --out CellWatch.apk app-release-unsigned.apk
```

Keep the keystore safe: future updates must be signed with the same one.

## 7. Legal boundaries (important)

- The app only reads public system information about **your own** device. It transmits nothing,
  impersonates no base station, and does not interfere with any network;
- **Never** use it to intercept communications, harvest other people's numbers or messages,
  commit fraud, or disturb public networks — these are criminal offences in most jurisdictions;
- Local radio and privacy law applies (e.g. radio regulations, wiretap statutes);
  verify legality before use;
- Provided “as is” under MIT, without warranty. You use it at your own risk.

---

## 版本记录 / Changelog

| 版本 | 内容 |
|---|---|
| 1.0 | 首个可运行版本：小区读取、5 条规则、CSV |
| 1.1 | 增加 RSRP/RSRQ/SINR/EARFCN/TA、邻区排行、趋势曲线、本机/SIM 面板、12 条规则 |
| 1.2 | 中英双语 + 运行时语言切换；本说明书；明确非原创来源与私密自用声明 |
| 1.3 | 全制式识别（2G/3G/4G/5G）+ 频段推算（LTE Bx / NR nx）+ 周边 WiFi 扫描（SSID/BSSID/信号/频段/加密）；新增 ACCESS_WIFI_STATE、CHANGE_WIFI_STATE 权限（普通权限，无需弹窗） |
| 1.4 | 研究模式：场景标记（地铁/商场/写字楼/户外/实验室）、JSON 结构化导出、唯一小区与标记统计；配套 `analyze.mjs` 分析脚本；本说明书新增“论文/参赛作品使用建议”一节 |
